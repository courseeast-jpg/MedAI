"""Local text extraction helpers."""

